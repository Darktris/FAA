class Particion():
    indicesTrain = []
    indicesTest = []

    def __init__(self):
        self.indicesTrain = []
        self.indicesTest = []
